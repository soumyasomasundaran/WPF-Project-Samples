﻿

namespace Calculator
{
    public class CalculatorMain
    {
        public double Add(double x, double y)
        {
            return x+y;
        }

        public double Subtract(double x, double y)
        {
            return x-y;
        }

        public double Multiply(double x, double y)
        {
            return x*y;
        }

        public double Divide(double x, double y)
        {
            try
            {
                return x / y;

            }
            catch (Exception)
            {
                return -1;
                //log error
            }
        }

        public double Sin(double degrees)
        {
            return Math.Sin(degrees * (Math.PI / 180));
        }



    }
}
