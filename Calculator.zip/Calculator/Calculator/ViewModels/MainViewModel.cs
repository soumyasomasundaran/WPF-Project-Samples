﻿using Calculator.Commands;
using Calculator.Commands.RelayCommand;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace Calculator.ViewModels
{
    public class MainViewModel: ValidationViewModelBase
    {
        public MainViewModel()
        {
            ButtonPressedCommand = new RelayCommand(ButtonPressed);
            ResultCommand = new RelayCommand(DisplayResult);
        }

        private void DisplayResult(object parameter)
        {
            CalculatorMain calculator = new CalculatorMain();
            switch (SelectedOperation)
            {
                case "+":
                    Result = calculator.Add(FirstNumber, SecondNumber);
                    break;

                case "-":
                    Result = calculator.Subtract(FirstNumber, SecondNumber);
                    break;

                case "*":
                    Result = calculator.Multiply(FirstNumber, SecondNumber);
                    break;
                case "/":
                    Result = calculator.Divide(FirstNumber, SecondNumber);
                    break;
                case "sin":
                    Result = calculator.Sin(FirstNumber);
                    break;


                default:
                    break;
            }
            OperationPerformed = $"{FirstNumber} {SelectedOperation} {SecondNumber} =";
            }

        public ICommand ButtonPressedCommand { get; set; }
        public ICommand ResultCommand { get; set; }
        private void ButtonPressed(object parameter)
        {
            SelectedOperation = (string)parameter;
            IsSecondNumberVisible = true;
            if (SelectedOperation == "sin")
            {
                IsSecondNumberVisible = false;
            }           
        }



        public bool IsSecondNumberVisible
        {
            get { return _isSecondNumberVisible; }
            set { 
                _isSecondNumberVisible = value;
                OnPropertyChanged(nameof(IsSecondNumberVisible));
            }
        }

        private string _selectedOperation;

        public string SelectedOperation
        {
            get { return _selectedOperation; }
            set { 
                _selectedOperation = value;
                OnPropertyChanged(nameof(SelectedOperation));            
            }
        }
        
        private string _operationPerformed;

        public string OperationPerformed
        {
            get { return _operationPerformed; }
            set { 
                _operationPerformed = value;
                OnPropertyChanged(nameof(OperationPerformed));            
            }
        }

        private double _firstNumber;

        public double FirstNumber
        {
            get { return _firstNumber; }
            set {
                _firstNumber = value; 

                if (!double.TryParse(FirstNumber.ToString(), out _))
                {
                    FirstNumber = double.NaN;
                    AddError("First Number should be double", nameof(FirstNumber));
                }


                /*if (FirstNumber<0)
                {
                    AddError("First Number should be > 0",nameof(FirstNumber));
                }*/
                else
                {
                    ClearErrors(nameof(FirstNumber));
                }

            }
        }       
        
        private double _secondNumber;

        public double SecondNumber
        {
            get { return _secondNumber; }
            set { 
                _secondNumber = value; 
                OnPropertyChanged(nameof(SecondNumber));
            
            }
        }
         private double _result;
        private bool _isSecondNumberVisible;

        public event EventHandler? CanExecuteChanged;

        public double Result
        {
            get { return _result; }
            set { 
                _result = value; 
                OnPropertyChanged(nameof(Result));
            
            }
        }

     
    }
}
