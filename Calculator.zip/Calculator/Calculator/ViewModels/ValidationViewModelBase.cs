﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.ViewModels
{
    public class ValidationViewModelBase : ViewModelBase, INotifyDataErrorInfo
    {
        private readonly Dictionary<string, List<string>> _errorByPropertyName = new();
        //returns true when object has errors
        public bool HasErrors => _errorByPropertyName.Any();    

        public event EventHandler<DataErrorsChangedEventArgs>? ErrorsChanged;

        /// <summary>
        /// returns collection of errors for property
        /// </summary>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IEnumerable GetErrors(string? propertyName)
        {
            return _errorByPropertyName is not null && _errorByPropertyName.ContainsKey(propertyName)?
                _errorByPropertyName[propertyName]
                :Enumerable.Empty<string>();
        }

        protected virtual void OnErrorsChanged(DataErrorsChangedEventArgs e)
        {
            ErrorsChanged?.Invoke(this, e);
        }

        protected void AddError(string Error, [CallerMemberName] string? PropertyName = null)
        {
            if (PropertyName is null)
            {
                return;
            }
            if (!_errorByPropertyName.ContainsKey(PropertyName))
            {
                _errorByPropertyName[PropertyName] = new List<string>();
            }
            if (!_errorByPropertyName[PropertyName].Contains(Error))
            {
                _errorByPropertyName[PropertyName].Add(Error);
                OnErrorsChanged(new DataErrorsChangedEventArgs(PropertyName));
                OnPropertyChanged(nameof(HasErrors));// check this
            }
            
        }

        protected void ClearErrors([CallerMemberName] string? PropertyName = null)
        {
            if (PropertyName is null)
            {
                return;
            }
            if (_errorByPropertyName.ContainsKey(PropertyName))
            {
                _errorByPropertyName.Remove(PropertyName);
                OnErrorsChanged(new DataErrorsChangedEventArgs(PropertyName));
                OnPropertyChanged(nameof(HasErrors));// check this
            }

        }

      
    }
}
